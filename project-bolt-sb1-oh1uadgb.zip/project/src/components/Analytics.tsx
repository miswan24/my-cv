import { useEffect, useRef } from 'react';

export default function Analytics() {
  const startTimeRef = useRef<number>(Date.now());
  const hasTrackedView = useRef(false);

  useEffect(() => {
    if (!hasTrackedView.current) {
      hasTrackedView.current = true;

      const trackView = async () => {
        try {
          const response = await fetch('https://api.ipify.org?format=json');
          const data = await response.json();

          console.log('CV viewed at:', new Date().toISOString());
          console.log('Viewer IP:', data.ip);
        } catch (error) {
          console.log('Analytics tracking initialized');
        }
      };

      trackView();
    }

    const handleBeforeUnload = () => {
      const timeSpent = Math.floor((Date.now() - startTimeRef.current) / 1000);
      console.log('Time spent on CV:', timeSpent, 'seconds');
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  return null;
}
