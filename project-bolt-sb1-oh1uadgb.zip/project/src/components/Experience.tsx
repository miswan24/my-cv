import { Briefcase, CheckCircle2 } from 'lucide-react';
import { Experience as ExperienceType } from '../types/cv';

interface ExperienceProps {
  experiences: ExperienceType[];
}

export default function Experience({ experiences }: ExperienceProps) {
  return (
    <section className="max-w-6xl mx-auto px-6 py-12 bg-slate-50">
      <div className="flex items-center gap-3 mb-8">
        <div className="bg-blue-600 p-3 rounded-lg">
          <Briefcase className="text-white" size={24} />
        </div>
        <h2 className="text-3xl font-bold text-slate-900">Work Experience</h2>
      </div>

      <div className="space-y-8">
        {experiences.map((exp, index) => (
          <div
            key={index}
            className="bg-white rounded-xl shadow-md p-8 hover:shadow-xl transition-shadow duration-300 border-l-4 border-blue-600"
          >
            <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">{exp.position}</h3>
                <p className="text-xl text-blue-600 mt-1">{exp.company}</p>
              </div>
              <div className="mt-2 md:mt-0">
                <span className="inline-block bg-slate-100 text-slate-700 px-4 py-2 rounded-full text-sm font-medium">
                  {exp.period}
                </span>
              </div>
            </div>

            <p className="text-slate-700 mb-4">{exp.description}</p>

            {exp.achievements && exp.achievements.length > 0 && (
              <div className="mt-4">
                <h4 className="font-semibold text-slate-900 mb-3">Key Achievements:</h4>
                <ul className="space-y-2">
                  {exp.achievements.map((achievement, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <CheckCircle2 className="text-green-600 flex-shrink-0 mt-1" size={18} />
                      <span className="text-slate-700">{achievement}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
