import { GraduationCap } from 'lucide-react';
import { Education as EducationType } from '../types/cv';

interface EducationProps {
  education: EducationType[];
}

export default function Education({ education }: EducationProps) {
  return (
    <section className="max-w-6xl mx-auto px-6 py-12">
      <div className="flex items-center gap-3 mb-8">
        <div className="bg-teal-600 p-3 rounded-lg">
          <GraduationCap className="text-white" size={24} />
        </div>
        <h2 className="text-3xl font-bold text-slate-900">Education</h2>
      </div>

      <div className="space-y-6">
        {education.map((edu, index) => (
          <div
            key={index}
            className="bg-white rounded-xl shadow-md p-8 hover:shadow-xl transition-shadow duration-300 border-l-4 border-teal-600"
          >
            <div className="flex flex-col md:flex-row md:items-start md:justify-between">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">{edu.degree}</h3>
                <p className="text-xl text-teal-600 mt-1">{edu.institution}</p>
                <p className="text-slate-600 mt-1">{edu.location}</p>
              </div>
              {edu.period && (
                <div className="mt-2 md:mt-0">
                  <span className="inline-block bg-slate-100 text-slate-700 px-4 py-2 rounded-full text-sm font-medium">
                    {edu.period}
                  </span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
