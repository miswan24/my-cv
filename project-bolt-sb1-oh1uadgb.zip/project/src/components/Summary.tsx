import { Sparkles } from 'lucide-react';

interface SummaryProps {
  summary: string;
}

export default function Summary({ summary }: SummaryProps) {
  return (
    <section className="max-w-6xl mx-auto px-6 py-12">
      <div className="relative bg-white rounded-2xl shadow-lg p-8 border border-slate-200 hover:shadow-xl transition-shadow duration-300">
        <div className="absolute -top-4 left-8">
          <div className="bg-gradient-to-r from-blue-600 to-teal-600 text-white px-6 py-2 rounded-full flex items-center gap-2 shadow-lg">
            <Sparkles size={18} />
            <span className="font-semibold">Professional Summary</span>
          </div>
        </div>
        <div className="mt-4">
          <p className="text-lg text-slate-700 leading-relaxed">{summary}</p>
        </div>
      </div>
    </section>
  );
}
