import { Mail, Phone, MapPin, Linkedin, Github } from 'lucide-react';

interface HeaderProps {
  name: string;
  title: string;
  photo: string;
  contact: {
    email?: string;
    phone?: string;
    location?: string;
    linkedin?: string;
    github?: string;
  };
}

export default function Header({ name, title, photo, contact }: HeaderProps) {
  return (
    <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]"></div>
      <div className="relative max-w-6xl mx-auto px-6 py-16">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-teal-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-300"></div>
            <img
              src={photo}
              alt={name}
              className="relative w-40 h-40 rounded-full object-cover border-4 border-white shadow-2xl"
            />
          </div>

          <div className="flex-1 text-center md:text-left">
            <h1 className="text-5xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent">
              {name}
            </h1>
            <p className="text-2xl text-slate-300 mb-6">{title}</p>

            <div className="flex flex-wrap gap-4 justify-center md:justify-start text-sm">
              {contact.email && (
                <a href={`mailto:${contact.email}`} className="flex items-center gap-2 hover:text-blue-400 transition">
                  <Mail size={16} />
                  <span>{contact.email}</span>
                </a>
              )}
              {contact.phone && (
                <a href={`tel:${contact.phone}`} className="flex items-center gap-2 hover:text-blue-400 transition">
                  <Phone size={16} />
                  <span>{contact.phone}</span>
                </a>
              )}
              {contact.location && (
                <div className="flex items-center gap-2">
                  <MapPin size={16} />
                  <span>{contact.location}</span>
                </div>
              )}
              {contact.linkedin && (
                <a href={`https://${contact.linkedin}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-blue-400 transition">
                  <Linkedin size={16} />
                  <span>LinkedIn</span>
                </a>
              )}
              {contact.github && (
                <a href={`https://${contact.github}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-blue-400 transition">
                  <Github size={16} />
                  <span>GitHub</span>
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
