import { Target, TrendingUp } from 'lucide-react';
import { Skill } from '../types/cv';

interface SkillsProps {
  skills: Skill[];
}

export default function Skills({ skills }: SkillsProps) {
  const iconColors = [
    'bg-blue-600',
    'bg-teal-600',
    'bg-green-600',
    'bg-orange-600'
  ];

  return (
    <section className="max-w-6xl mx-auto px-6 py-12 bg-slate-50">
      <div className="flex items-center gap-3 mb-8">
        <div className="bg-green-600 p-3 rounded-lg">
          <Target className="text-white" size={24} />
        </div>
        <h2 className="text-3xl font-bold text-slate-900">Skills & Expertise</h2>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {skills.map((skillGroup, index) => (
          <div
            key={index}
            className="bg-white rounded-xl shadow-md p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className={`${iconColors[index % iconColors.length]} p-2 rounded-lg`}>
                <TrendingUp className="text-white" size={20} />
              </div>
              <h3 className="text-xl font-bold text-slate-900">{skillGroup.category}</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {skillGroup.items.map((skill, skillIdx) => (
                <span
                  key={skillIdx}
                  className="bg-gradient-to-r from-slate-100 to-slate-200 text-slate-800 px-4 py-2 rounded-full text-sm font-medium hover:from-blue-50 hover:to-teal-50 hover:text-blue-900 transition-colors duration-200"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 bg-gradient-to-r from-blue-50 to-teal-50 rounded-xl p-6 border border-blue-200">
        <div className="flex items-start gap-4">
          <div className="bg-blue-600 p-3 rounded-lg">
            <Target className="text-white" size={24} />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">Core Strengths</h3>
            <p className="text-slate-700 leading-relaxed">
              <span className="font-semibold text-blue-900">Analytical Thinking:</span> Expert in data-driven decision making, identifying patterns, and translating complex requirements into actionable insights.
            </p>
            <p className="text-slate-700 leading-relaxed mt-2">
              <span className="font-semibold text-teal-900">Problem Solving:</span> Proven track record of resolving complex technical and operational challenges through systematic analysis and creative solutions.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
