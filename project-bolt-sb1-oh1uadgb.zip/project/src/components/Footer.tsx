import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-8">
      <div className="max-w-6xl mx-auto px-6 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <span className="text-slate-400">Crafted with</span>
          <Heart className="text-red-500 fill-red-500" size={18} />
          <span className="text-slate-400">by Miswanto</span>
        </div>
        <p className="text-slate-500 text-sm">
          &copy; {new Date().getFullYear()} Miswanto. All rights reserved.
        </p>
        <p className="text-slate-600 text-xs mt-2">
          This CV is best viewed on modern browsers
        </p>
      </div>
    </footer>
  );
}
