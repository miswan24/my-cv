import { Rocket, TrendingUp } from 'lucide-react';
import { Project } from '../types/cv';

interface ProjectsProps {
  projects: Project[];
}

export default function Projects({ projects }: ProjectsProps) {
  return (
    <section className="max-w-6xl mx-auto px-6 py-12">
      <div className="flex items-center gap-3 mb-8">
        <div className="bg-orange-600 p-3 rounded-lg">
          <Rocket className="text-white" size={24} />
        </div>
        <h2 className="text-3xl font-bold text-slate-900">Projects & Portfolio</h2>
      </div>

      <div className="space-y-6">
        {projects.map((project, index) => (
          <div
            key={index}
            className="bg-gradient-to-br from-white to-slate-50 rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all duration-300 border border-slate-200 hover:-translate-y-1"
          >
            <div className="flex items-start gap-4">
              <div className="bg-gradient-to-br from-orange-500 to-red-500 p-4 rounded-xl">
                <Rocket className="text-white" size={28} />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-slate-900 mb-3">{project.name}</h3>
                <p className="text-slate-700 leading-relaxed mb-4">{project.description}</p>

                {project.metrics && (
                  <div className="bg-gradient-to-r from-green-50 to-teal-50 rounded-lg p-4 border-l-4 border-green-500">
                    <div className="flex items-start gap-3">
                      <TrendingUp className="text-green-600 flex-shrink-0 mt-1" size={20} />
                      <div>
                        <h4 className="font-semibold text-green-900 mb-1">Impact & Results</h4>
                        <p className="text-slate-700">{project.metrics}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
