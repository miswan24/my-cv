import { CVData } from '../types/cv';

export const cvData: CVData = {
  name: 'Miswanto',
  title: 'Project Manager & Product Manager',
  photo: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400',
  contact: {
    email: 'miswanto@example.com',
    phone: '+62 XXX XXXX XXXX',
    location: 'Jakarta, Indonesia',
    linkedin: 'linkedin.com/in/miswanto',
    github: 'github.com/miswanto'
  },
  summary: 'Experienced Project Manager with proven analytical capabilities and problem-solving expertise in international startup environments. Successfully delivered 80% success rate in project delivery while managing cross-functional teams. Specialized in product management with deep understanding of Agile methodologies and modern project management tools including Jira, Asana, and Trello.',
  experiences: [
    {
      company: 'Startup Internasional',
      position: 'Project Manager',
      period: 'Juni 2023 - Sekarang',
      description: 'Leading project management initiatives at international startup headquartered in China',
      achievements: [
        'Successfully coordinated cross-border teams across multiple time zones',
        'Implemented Agile methodologies using Jira for sprint planning and tracking',
        'Established data-driven decision making processes through analytics',
        'Improved team collaboration efficiency by 40% through streamlined workflows'
      ]
    },
    {
      company: 'Wiz AI',
      position: 'Project Manager',
      period: 'Mei 2023 - Mei 2024',
      description: 'Managed multiple projects at international startup with focus on AI-driven solutions',
      achievements: [
        'Achieved 80% successful delivery rate across all managed projects',
        'Led product development cycles from ideation to deployment',
        'Utilized Asana and Trello for task management and team coordination',
        'Resolved complex technical and operational challenges through analytical approach'
      ]
    }
  ],
  education: [
    {
      degree: 'S2 Ilmu Komputer',
      institution: 'Universitas Nusa Mandiri',
      location: 'Jakarta',
      period: '2020 - 2022'
    }
  ],
  skills: [
    {
      category: 'Project Management Tools',
      items: ['Jira', 'Asana', 'Trello', 'Notion', 'Confluence']
    },
    {
      category: 'Core Competencies',
      items: ['Analytical Thinking', 'Problem Solving', 'Agile/Scrum', 'Product Strategy', 'Stakeholder Management']
    },
    {
      category: 'Technical Knowledge',
      items: ['Software Development Lifecycle', 'Data Analysis', 'API Integration', 'Cloud Platforms', 'SaaS Products']
    },
    {
      category: 'Soft Skills',
      items: ['Cross-cultural Communication', 'Team Leadership', 'Strategic Planning', 'Risk Management', 'Change Management']
    }
  ],
  projects: [
    {
      name: 'tts.prosa.ai - SaaS Text-to-Speech Platform',
      description: 'Led the development and launch of Prosa.ai\'s first SaaS application, a text-to-speech platform that democratized AI voice technology for Indonesian market',
      metrics: 'Achieved 50,000+ users within 3 months of launch, demonstrating strong product-market fit and effective go-to-market strategy'
    }
  ]
};
