import { useEffect, useState } from 'react';
import Header from './components/Header';
import Summary from './components/Summary';
import Experience from './components/Experience';
import Education from './components/Education';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Footer from './components/Footer';
import SEO from './components/SEO';
import Analytics from './components/Analytics';
import { cvData } from './data/cvData';
import { Download } from 'lucide-react';

function App() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <SEO
        title={`${cvData.name} - ${cvData.title} | Professional CV`}
        description={`Professional CV of ${cvData.name}, an experienced ${cvData.title} specializing in project management, product strategy, analytical thinking, and problem-solving. Proven track record with Jira, Asana, and Trello.`}
        keywords="project manager, product manager, analytical thinking, problem solving, Jira, Asana, Trello, agile, scrum, project management, startup, SaaS, international team, cross-functional leadership"
        author={cvData.name}
      />
      <Analytics />

      <div
        className={`transition-all duration-1000 transform ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <Header
          name={cvData.name}
          title={cvData.title}
          photo={cvData.photo}
          contact={cvData.contact}
        />

        <button
          onClick={handlePrint}
          className="fixed right-8 top-8 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center gap-2 z-50 print:hidden"
        >
          <Download size={20} />
          <span className="font-medium">Download PDF</span>
        </button>

        <Summary summary={cvData.summary} />
        <Experience experiences={cvData.experiences} />
        <Education education={cvData.education} />
        <Skills skills={cvData.skills} />
        <Projects projects={cvData.projects} />
        <Footer />
      </div>
    </div>
  );
}

export default App;
