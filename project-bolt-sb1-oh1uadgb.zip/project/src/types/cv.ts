export interface Experience {
  company: string;
  position: string;
  period: string;
  description: string;
  achievements?: string[];
}

export interface Education {
  degree: string;
  institution: string;
  location: string;
  period?: string;
}

export interface Project {
  name: string;
  description: string;
  metrics?: string;
}

export interface Skill {
  category: string;
  items: string[];
}

export interface CVData {
  name: string;
  title: string;
  photo: string;
  contact: {
    email?: string;
    phone?: string;
    location?: string;
    linkedin?: string;
    github?: string;
  };
  summary: string;
  experiences: Experience[];
  education: Education[];
  skills: Skill[];
  projects: Project[];
}
