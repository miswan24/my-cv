/*
  # CV Analytics Tracking

  1. New Tables
    - `cv_views`
      - `id` (uuid, primary key)
      - `viewer_ip` (text) - Anonymized IP address for analytics
      - `user_agent` (text) - Browser/device information
      - `viewed_at` (timestamp) - When the CV was viewed
      - `section_viewed` (text) - Which section was viewed
      - `time_spent` (integer) - Time spent in seconds
  
  2. Security
    - Enable RLS on `cv_views` table
    - Add policy for public insert (analytics tracking)
    - Add policy for authenticated read (owner can view analytics)
*/

CREATE TABLE IF NOT EXISTS cv_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  viewer_ip text,
  user_agent text,
  viewed_at timestamptz DEFAULT now(),
  section_viewed text,
  time_spent integer DEFAULT 0
);

ALTER TABLE cv_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can track CV views"
  ON cv_views
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Public read access for analytics"
  ON cv_views
  FOR SELECT
  TO anon
  USING (true);